package org.afpa.thoth80.melangeurdecouleur;

import javafx.fxml.Initializable;
import javafx.scene.control.Slider;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

import java.net.URL;
import java.util.ResourceBundle;

public class InterfaceController implements Initializable {
    public Rectangle finalColor;
    public Slider greenFieldController;
    public Slider blueFieldController;
    public Slider redFieldController;
    public Rectangle redField;
    public Rectangle greenField;
    public Rectangle blueField;
    public Double greenValue = 0d;
    public Double blueValue = 0d;
    public Double redValue = 0d;
    public TextField finalValue;

    @Override
    public void initialize(URL location, ResourceBundle resources) {

        redField.setFill(Color.rgb(255,255,255));
        greenField.setFill(Color.rgb(255,255,255));
        blueField.setFill(Color.rgb(255,255,255));
        finalColor.setFill(Color.rgb(255,255,255));


        redFieldController.setMin(0);
        redFieldController.setMax(255);
        redFieldController.setValue(0);
        redFieldController.valueProperty().addListener(e->{
            redValue = redFieldController.getValue();
            redField.setFill(Color.rgb(redValue.intValue(), 0, 0));
            finalColor.setFill(Color.rgb(redValue.intValue(),greenValue.intValue(), blueValue.intValue()));
            finalValue.clear();
            finalValue.appendText("rgb("+redValue.intValue()+","+greenValue.intValue()+","+blueValue.intValue()+")");

        });

        greenFieldController.setMin(0);
        greenFieldController.setMax(255);
        greenFieldController.setValue(0);
        greenFieldController.valueProperty().addListener(e->{
            greenValue = greenFieldController.getValue();
            greenField.setFill(Color.rgb(0, greenValue.intValue(), 0));
            finalColor.setFill(Color.rgb(redValue.intValue(),greenValue.intValue(), blueValue.intValue()));
            finalValue.clear();
            finalValue.appendText("rgb("+redValue.intValue()+","+greenValue.intValue()+","+blueValue.intValue()+")");
        });

        blueFieldController.setMin(0);
        blueFieldController.setMax(255);
        blueFieldController.setValue(0);
        blueFieldController.valueProperty().addListener(e->{
            blueValue = blueFieldController.getValue();
            blueField.setFill(Color.rgb(0, 0, blueValue.intValue()));
            finalColor.setFill(Color.rgb(redValue.intValue(),greenValue.intValue(), blueValue.intValue()));
            finalValue.clear();
            finalValue.appendText("rgb("+redValue.intValue()+","+greenValue.intValue()+","+blueValue.intValue()+")");
        });
    }
}
