package org.afpa.thoth80.casesAcocher;

import javafx.beans.Observable;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.input.InputMethodEvent;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class InterfaceController implements Initializable {
    public TextField interfaceOutput;
    public TextField userInput;

    public AnchorPane backGroundColor;

    /*
    Création d'un groupe de radio boutons
     */
    public ToggleGroup backgroundColorToggleGroup = new ToggleGroup();
    public RadioButton radioBackgroundRed;
    public RadioButton radioBackgroundGreen;
    public RadioButton radioBackgroundBlue;

    public AnchorPane fontColor;
    public ToggleGroup fontColorToggleGroup = new ToggleGroup();
    public RadioButton radioFontRed;
    public RadioButton radioFontWhite;
    public RadioButton radioFontBlack;

    public AnchorPane fontCase;
    public ToggleGroup caseToggleGroup = new ToggleGroup();
    public RadioButton radioLowerCase;
    public RadioButton radioUpperCase;

    public AnchorPane userChoices;
    public CheckBox backgroundColorCheckBox;
    public CheckBox fontColorCheckBox;
    public CheckBox caseSizeCheckBox;
    public String interfaceOutputCssStyle = "";
    public String backgroundCssStyle = "";
    public String textCssStyle = "";



    public void radioToToggleGroup(ToggleGroup targetToggleGroup, RadioButton ... radioButtons){
        for (RadioButton radioButton : radioButtons){
            radioButton.setToggleGroup(targetToggleGroup);
        }
    }




    @Override
    public void initialize(URL location, ResourceBundle resources) {

        /*
        Reglage de l'affichage par défaut et deblocage du block userChoices si text dans le userInput
         */
        userInput.textProperty().addListener(evt->{
            interfaceOutput.clear();
            interfaceOutput.setVisible(true);
            userChoices.setDisable(false);
            interfaceOutput.appendText(userInput.getText());
        });
        interfaceOutput.setDisable(true);
        interfaceOutput.setVisible(false);
        userChoices.setDisable(true);
        backGroundColor.setDisable(true);
        fontColor.setDisable(true);
        fontCase.setDisable(true);

        /*
        On met les radios dans leurs groupes respectifs
         */
        radioToToggleGroup(backgroundColorToggleGroup,radioBackgroundRed, radioBackgroundGreen,  radioBackgroundBlue);
        radioToToggleGroup(fontColorToggleGroup, radioFontRed, radioFontWhite, radioFontBlack);
        radioToToggleGroup(caseToggleGroup, radioLowerCase, radioUpperCase);

        /*
        Si checkbox backgroundColor checked
        */
        backgroundColorCheckBox.setOnAction(e->{
            if(backgroundColorCheckBox.isSelected()){
                backGroundColor.setDisable(false);
            }
            else{
                backGroundColor.setDisable(true);
            }
        });

        /*
        On passe en revue la liste des radios bouton dans le togglegroup et on met un écouteur sur chacun pour voir si on le sélectionne
         */
        for( Toggle button :  backgroundColorToggleGroup.getToggles()){
            ((RadioButton) button).setOnAction(e->{
                switch (((RadioButton) button).getText().toUpperCase()){
                    case "ROUGE":
                        backgroundCssStyle = "-fx-background-color: red;";
                        interfaceOutputCssStyle = backgroundCssStyle.concat(textCssStyle);
                        interfaceOutput.setStyle(interfaceOutputCssStyle);
                        break;
                    case "VERT":
                        backgroundCssStyle = "-fx-background-color: green;";
                        interfaceOutputCssStyle = backgroundCssStyle.concat(textCssStyle);
                        interfaceOutput.setStyle(interfaceOutputCssStyle);
                        break;
                    case "BLEU":
                        backgroundCssStyle = "-fx-background-color: blue;";
                        interfaceOutputCssStyle = backgroundCssStyle.concat(textCssStyle);
                        interfaceOutput.setStyle(interfaceOutputCssStyle);
                }
            });
        }

        fontColorCheckBox.setOnAction(e->{
            if(fontColorCheckBox.isSelected()){
                fontColor.setDisable(false);
            }
            else{
                fontColor.setDisable(true);
            }
        });
        for( Toggle button :  fontColorToggleGroup.getToggles()){
            ((RadioButton) button).setOnAction(e->{
                switch (((RadioButton) button).getText().toUpperCase()){
                    case "ROUGE":
                        textCssStyle = "-fx-text-fill: red;";
                        interfaceOutputCssStyle = backgroundCssStyle.concat(textCssStyle);
                        interfaceOutput.setStyle(interfaceOutputCssStyle);
                        break;
                    case "BLANC":
                        textCssStyle = "-fx-text-fill: white;";
                        interfaceOutputCssStyle = backgroundCssStyle.concat(textCssStyle);
                        interfaceOutput.setStyle(interfaceOutputCssStyle);
                        break;
                    case "NOIR":
                        textCssStyle = "-fx-text-fill: black;";
                        interfaceOutputCssStyle = backgroundCssStyle.concat(textCssStyle);
                        interfaceOutput.setStyle(interfaceOutputCssStyle);
                        break;
                }
            });
        }

        caseSizeCheckBox.setOnAction(e->{
            if(caseSizeCheckBox.isSelected()){
                fontCase.setDisable(false);
            }
            else{
                fontCase.setDisable(true);
            }
        });
        for( Toggle button :  caseToggleGroup.getToggles()){
            ((RadioButton) button).setOnAction(e->{
                switch (((RadioButton) button).getText().toUpperCase()){
                    case "MAJUSCULE":
                        interfaceOutput.clear();
                        interfaceOutput.appendText(userInput.getText().toUpperCase());
                        break;
                    case "MINUSCULE":
                        interfaceOutput.clear();
                        interfaceOutput.appendText(userInput.getText().toLowerCase());
                        break;
                }
            });
        }
    }
}
