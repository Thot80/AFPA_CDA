package org.afpa.thoth80.additionneur;

import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.HBox;

public class AddController {
    public AnchorPane app;

    public Button btn0;
    public Button btn1;
    public Button btn2;
    public Button btn3;
    public Button btn4;
    public Button btn5;
    public Button btn6;
    public Button btn7;
    public Button btn8;
    public Button btn9;
    public Button btnClear;
    public Button btnCompute;
    public TextArea screen;
    public int somme = 0;


    public void btn_clicked(ActionEvent actionEvent) {


        Button btnActive = (Button) actionEvent.getSource();
        if(btnActive == btn0){
            somme += 0;
            screen.appendText("+0");
        }
        else if(btnActive == btn1){
            somme += 1;
            screen.appendText("+1");
        }
        else if(btnActive == btn2){
            somme += 2;
            screen.appendText("+2");
        }
        else if(btnActive == btn3){
            somme += 3;
            screen.appendText("+3");
        }
        else if(btnActive == btn4){
            somme += 4;
            screen.appendText("+4");
        }
        else if(btnActive == btn5){
            somme += 5;
            screen.appendText("+5");
        }
        else if(btnActive == btn6){
            somme += 6;
            screen.appendText("+6");
        }
        else if(btnActive == btn7){
            somme += 7;
            screen.appendText("+7");
        }
        else if(btnActive == btn8){
            somme += 8;
            screen.appendText("+8");
        }
        else if(btnActive == btn9){
            somme += 9;
            screen.appendText("+9");
        }
        else if(btnActive == btnClear){
            screen.clear();
        }
        else if(btnActive == btnCompute){
            screen.appendText(" = "+somme);
        }
    }
}
